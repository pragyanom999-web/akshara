# Akshara PWA

Put the existing `logo.png` in this same folder as `index.html`.

## GitHub Pages
Upload all four files to the repository and enable GitHub Pages.

The site is a responsive Progressive Web App (PWA). On supported mobile browsers,
the browser can offer **Install app / Add to Home screen**, using `logo.png` as the
application icon and splash-screen branding.

The page includes working navigation, search, notifications, profile, subject/course
actions, learning actions, progress/library views, and an install action.
